#!/usr/bin/env python3
"""Validate a mobile update manifest without network access or credentials."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path
from urllib.parse import urlparse


REQUIRED = (
    "versionName",
    "minimumVersion",
    "mandatory",
    "publishedAt",
    "releaseNotes",
    "downloadUrl",
    "fileSize",
    "sha256",
    "signingIdentity",
)
IOS_DISTRIBUTIONS = {"app-store", "testflight", "mdm"}
HEX_64 = re.compile(r"^[0-9a-f]{64}$")
BADGING_PACKAGE = re.compile(r"^package:\s+name='([^']+)'\s+versionCode='(\d+)'", re.MULTILINE)
SIGNER_SHA256 = re.compile(
    r"Signer\s+#1\s+certificate\s+SHA-256\s+digest:\s*([0-9A-Fa-f:]+)", re.IGNORECASE
)


def fail(message: str) -> None:
    print(f"FAIL: {message}", file=sys.stderr)
    raise SystemExit(1)


def android_package_path(channel: object) -> str:
    if channel == "stable":
        return "/mobile-updates/packages/"
    if channel == "debug":
        return "/mobile-updates/debug-packages/"
    fail("Android channel must be stable or debug")


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def run_tool(command: list[str], label: str) -> str:
    try:
        completed = subprocess.run(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=30,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as error:
        fail(f"cannot run {label}: {error}")
    if completed.returncode != 0:
        fail(f"{label} rejected the package")
    return completed.stdout


def parse_badging(output: str) -> tuple[str, int]:
    match = BADGING_PACKAGE.search(output)
    if not match:
        fail("aapt output did not contain package name and versionCode")
    return match.group(1), int(match.group(2))


def parse_signer_sha256(output: str) -> str:
    match = SIGNER_SHA256.search(output)
    if not match:
        fail("apksigner output did not contain the signer SHA-256 digest")
    value = re.sub(r"[^0-9A-Fa-f]", "", match.group(1)).lower()
    if not HEX_64.fullmatch(value):
        fail("apksigner returned an invalid signer SHA-256 digest")
    return value


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Validate a mobile HTTPS update manifest and optional local package."
    )
    parser.add_argument("manifest", type=Path)
    parser.add_argument("--package", type=Path, help="immutable candidate package to hash")
    parser.add_argument(
        "--installed-apk",
        type=Path,
        help="signed installed Android baseline; derives its signer without accessing a key",
    )
    parser.add_argument("--aapt", type=Path, help="official Android aapt executable for package audit")
    parser.add_argument("--expected-package-id", help="expected Android application ID")
    parser.add_argument("--apksigner", type=Path, help="official Android apksigner executable")
    parser.add_argument(
        "--expected-signer-sha256",
        help="expected APK signer certificate SHA-256 fingerprint",
    )
    parser.add_argument(
        "--installed-version-code", type=int, help="require manifest versionCode to be greater"
    )
    args = parser.parse_args()

    try:
        manifest = json.loads(args.manifest.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
        fail(f"cannot read JSON manifest: {error}")
    if not isinstance(manifest, dict):
        fail("manifest root must be an object")
    missing = [name for name in REQUIRED if name not in manifest]
    if missing:
        fail("missing required fields: " + ", ".join(missing))
    platform = str(manifest.get("platform", "android")).lower()
    if platform not in {"android", "ios"}:
        fail("platform must be android or ios")
    if not isinstance(manifest["versionName"], str) or not manifest["versionName"].strip():
        fail("versionName must be a non-empty string")
    code_field = "build" if platform == "ios" and "build" in manifest else "versionCode"
    if not isinstance(manifest.get(code_field), int) or manifest[code_field] <= 0:
        fail(f"{code_field} must be a positive integer")
    version_code = manifest[code_field]
    minimum = manifest["minimumVersion"]
    if isinstance(minimum, int):
        if minimum < 0:
            fail("numeric minimumVersion must be non-negative")
    elif not isinstance(minimum, str) or not minimum.strip():
        fail("minimumVersion must be a non-negative integer or non-empty version string")
    if not isinstance(manifest["mandatory"], bool):
        fail("mandatory must be a boolean")
    if not isinstance(manifest["fileSize"], int) or manifest["fileSize"] < 0:
        fail("fileSize must be a non-negative integer")
    if platform == "android" and manifest["fileSize"] <= 0:
        fail("Android fileSize must be a positive integer")
    if not isinstance(manifest["releaseNotes"], str) or not isinstance(manifest["publishedAt"], str):
        fail("publishedAt and releaseNotes must be strings")
    url = urlparse(str(manifest["downloadUrl"]))
    if url.scheme != "https" or not url.netloc or url.username or url.password:
        fail("downloadUrl must be an absolute HTTPS URL")
    if platform == "android" and (
        url.query
        or url.fragment
        or not re.fullmatch(
            re.escape(android_package_path(manifest.get("channel", "stable")))
            + r"[A-Za-z0-9][A-Za-z0-9._-]*\.apk",
            url.path,
        )
    ):
        fail("Android downloadUrl must be a direct immutable APK path without query or fragment")
    if platform == "ios":
        if manifest.get("distribution") not in IOS_DISTRIBUTIONS:
            fail("iOS distribution must be app-store, testflight, or mdm")
    expected_hash = str(manifest["sha256"]).lower()
    if not HEX_64.fullmatch(expected_hash):
        fail("sha256 must be 64 hexadecimal characters")
    signer = str(manifest["signingIdentity"])
    if not re.fullmatch(r"sha256:[0-9a-f]{64}", signer):
        fail("signingIdentity must be sha256: followed by lowercase 64-hex fingerprint")
    if args.installed_version_code is not None and version_code <= args.installed_version_code:
        fail(f"{code_field} is not greater than installed version")
    if platform == "ios" and any((args.package, args.installed_apk, args.aapt, args.apksigner, args.expected_package_id, args.expected_signer_sha256)):
        fail("Android APK audit options cannot be used with an iOS manifest")
    if bool(args.aapt) != bool(args.expected_package_id):
        fail("--aapt and --expected-package-id must be supplied together")
    if args.installed_apk is not None:
        if not args.installed_apk.is_file():
            fail("installed APK does not exist")
        if not args.aapt or not args.apksigner or not args.expected_package_id:
            fail("--installed-apk requires --aapt, --apksigner, and --expected-package-id")
        if args.expected_signer_sha256:
            fail("use either --installed-apk or --expected-signer-sha256, not both")
    elif bool(args.apksigner) != bool(args.expected_signer_sha256):
        fail("--apksigner and --expected-signer-sha256 must be supplied together")
    if (args.aapt or args.apksigner) and args.package is None and args.installed_apk is None:
        fail("Android package audit requires --package or --installed-apk")

    expected_signer = None
    if args.installed_apk is not None:
        installed_package_id, installed_version = parse_badging(
            run_tool([str(args.aapt), "dump", "badging", str(args.installed_apk)], "aapt")
        )
        if installed_package_id != args.expected_package_id:
            fail("installed APK package ID differs from expected package ID")
        if version_code <= installed_version:
            fail("manifest versionCode is not greater than installed APK versionCode")
        expected_signer = parse_signer_sha256(
            run_tool(
                [str(args.apksigner), "verify", "--verbose", "--print-certs", str(args.installed_apk)],
                "apksigner",
            )
        )
        if manifest["signingIdentity"] != f"sha256:{expected_signer}":
            fail("manifest signingIdentity differs from installed APK signer")
    if args.package is not None:
        if not args.package.is_file():
            fail("package does not exist")
        if args.package.stat().st_size != manifest["fileSize"]:
            fail("package byte size differs from manifest")
        if file_sha256(args.package) != expected_hash:
            fail("package SHA-256 differs from manifest")
        if args.aapt:
            package_id, package_version = parse_badging(
                run_tool([str(args.aapt), "dump", "badging", str(args.package)], "aapt")
            )
            if package_id != args.expected_package_id:
                fail("APK package ID differs from expected package ID")
            if package_version != version_code:
                fail("APK versionCode differs from manifest")
        if args.apksigner:
            signer = parse_signer_sha256(
                run_tool(
                    [str(args.apksigner), "verify", "--verbose", "--print-certs", str(args.package)],
                    "apksigner",
                )
            )
            expected_signer = expected_signer or str(args.expected_signer_sha256).lower()
            if not HEX_64.fullmatch(expected_signer):
                fail("expected signer SHA-256 must be 64 hexadecimal characters")
            if signer != expected_signer:
                fail("APK signer differs from expected signer")
            if manifest["signingIdentity"] != f"sha256:{signer}":
                fail("APK signer differs from manifest signingIdentity")
    print(
            "PASS: manifest version={}/{} HTTPS package={} signer={}".format(
            manifest["versionName"], version_code, url.path, signer
        )
    )


if __name__ == "__main__":
    main()
