#!/usr/bin/env python3
"""Restore only the preserved 91014 Android Debug manifest after 91015."""
from __future__ import annotations

import fcntl
import stat
from contextlib import contextmanager
import hashlib
import json
import os
import socket
import tempfile
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

HOST = "iZ2vc2shy5e95mfqeid9khZ"
ROOT = Path("/var/www/erp-uat-updates")
MANIFEST = ROOT / "android/debug.json"
APK_NAME = "feihong-erp-0.9.15-debug.15.apk"
OLD_APK_NAME = "feihong-erp-0.9.14-debug.14.apk"
PACKAGE = ROOT / "debug-packages" / APK_NAME
OLD_PACKAGE = ROOT / "debug-packages" / OLD_APK_NAME
BACKUP = ROOT / "archive/DEBUG-91015-20261007"
OLD_MANIFEST_SHA = "c36d3f5d3147e4f2b6802631ec48ffa89400f9bc3a9d90b5c914532e2b778ea2"
OLD_APK_SHA = "8b2e60902e297b276cd72d48b539e7fd9dc698de7741db61f3ad2c0ce1da2460"
NEW_APK_SHA = "049a46f1425531a77c93c610f242b6a2783edc02b34423e9f6a1bfac3ad8dc24"
NEW_APK_SIZE = 1038411
SIGNER = "sha256:a182e8f2b6b60e71acf6e29184558fd3b210b5c8748a8beeb75de0bace3355a4"
MANIFEST_URL = "https://api-test.scxmj.cn/mobile-updates/android/debug.json"
OLD_PACKAGE_URL = "https://api-test.scxmj.cn/mobile-updates/debug-packages/" + OLD_APK_NAME
NEW_PACKAGE_URL = "https://api-test.scxmj.cn/mobile-updates/debug-packages/" + APK_NAME
ORIGIN = "https://appassets.androidplatform.net"


@contextmanager
def release_lock():
    require(socket.gethostname() == HOST and os.geteuid() == 0, "wrong host or execution user")
    require(ROOT.is_dir() and not ROOT.is_symlink(), "root missing or symlinked")
    lockpath = ROOT / ".android-debug-release.lock"
    fd = os.open(lockpath, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
    try:
        st = os.fstat(fd)
        require(stat.S_ISREG(st.st_mode) and st.st_nlink == 1 and st.st_uid == 0,
                "release lock identity mismatch")
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        yield
    finally:
        os.close(fd)
    # Keep lock inode; deleting it would let different processes lock different inodes.


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def digest(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def file_sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def parse(raw: bytes) -> dict:
    def unique_pairs(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "duplicate JSON field")
            result[key] = value
        return result
    value = json.loads(raw.decode("utf-8"), object_pairs_hook=unique_pairs)
    require(type(value) is dict, "JSON value must be an object")
    return value


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def fetch(url: str, expected_size: int) -> tuple[bytes, dict[str, str]]:
    req = urllib.request.Request(url, headers={"Origin": ORIGIN, "Cache-Control": "no-cache"})
    with urllib.request.build_opener(NoRedirect()).open(req, timeout=30) as response:
        require(response.status == 200 and response.geturl() == url, "HTTPS status/redirect mismatch")
        require(response.headers.get_all("Access-Control-Allow-Origin") == [ORIGIN], "HTTPS CORS mismatch")
        require("Origin" in response.headers.get("Vary", ""), "HTTPS Vary mismatch")
        raw = response.read(expected_size + 1)
        require(len(raw) == expected_size, "HTTPS response byte count mismatch")
        return raw, {k.lower(): v for k, v in response.headers.items()}


def fsync_dir(directory: Path) -> None:
    fd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def atomic_write(target: Path, raw: bytes, mode: int) -> None:
    fd, name = tempfile.mkstemp(prefix="." + target.name + ".", suffix=".tmp", dir=target.parent)
    staged = Path(name)
    try:
        with os.fdopen(fd, "wb") as stream:
            os.fchmod(stream.fileno(), mode)
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        require(staged.read_bytes() == raw, "rollback staged manifest mismatch")
        os.replace(staged, target)
        fsync_dir(target.parent)
    finally:
        staged.unlink(missing_ok=True)


def verify_old(raw: bytes, apk_path: Path) -> int:
    require(digest(raw) == OLD_MANIFEST_SHA, "preserved 91014 manifest SHA mismatch")
    old = parse(raw)
    size = apk_path.stat().st_size
    require(file_sha(apk_path) == OLD_APK_SHA, "preserved 91014 APK SHA mismatch")
    require(type(old.get("versionCode")) is int and old["versionCode"] == 91014 and
            old.get("versionName") == "0.9.14-debug.14" and old.get("channel") == "debug" and
            old.get("downloadUrl") == OLD_PACKAGE_URL and old.get("fileSize") == size and
            old.get("sha256") == OLD_APK_SHA and old.get("signingIdentity") == SIGNER,
            "preserved 91014 manifest identity mismatch")
    return size


def verify_current_91015(raw: bytes) -> dict:
    new = parse(raw)
    require(type(new.get("versionCode")) is int and new["versionCode"] == 91015 and
            new.get("versionName") == "0.9.15-debug.15" and new.get("channel") == "debug" and
            new.get("downloadUrl") == NEW_PACKAGE_URL and new.get("fileSize") == NEW_APK_SIZE and
            new.get("sha256") == NEW_APK_SHA and new.get("signingIdentity") == SIGNER,
            "current manifest is not the expected 91015 Debug release")
    require(PACKAGE.is_file() and not PACKAGE.is_symlink() and PACKAGE.stat().st_size == NEW_APK_SIZE and
            file_sha(PACKAGE) == NEW_APK_SHA, "current 91015 APK path/size/SHA mismatch")
    return new


def verify_https(expected_raw: bytes, apk_sha: str, apk_size: int, version: int,
                 name: str, url: str) -> dict:
    manifest, mh = fetch(MANIFEST_URL, len(expected_raw))
    require(digest(manifest) == digest(expected_raw), "HTTPS manifest readback mismatch")
    require("no-store" in mh.get("cache-control", "").lower(), "manifest Cache-Control lacks no-store")
    data = parse(manifest)
    require(type(data.get("versionCode")) is int and data["versionCode"] == version and
            data.get("versionName") == name and data.get("channel") == "debug" and
            data.get("downloadUrl") == url and data.get("sha256") == apk_sha and
            data.get("fileSize") == apk_size and data.get("signingIdentity") == SIGNER,
            "HTTPS manifest fields mismatch")
    package, ph = fetch(url, apk_size)
    require(digest(package) == apk_sha, "HTTPS APK SHA mismatch")
    return {"manifestBytes": len(manifest), "manifestSha256": digest(manifest),
            "manifestCacheControl": mh.get("cache-control", ""), "apkBytes": len(package),
            "apkSha256": digest(package), "apkCacheControl": ph.get("cache-control", "")}


def rollback() -> None:
    require(socket.gethostname() == HOST, "must run on authorized 91015 server")
    require(ROOT.is_dir() and not ROOT.is_symlink(), "authorized root missing or symlinked")
    root_real = ROOT.resolve(strict=True)
    for child in ("android", "debug-packages", "archive"):
        directory = ROOT / child
        require(directory.is_dir() and not directory.is_symlink() and
                directory.resolve(strict=True) == root_real / child,
                "rollback directory missing, symlinked, or escaped root: " + child)
    require(MANIFEST.is_file() and not MANIFEST.is_symlink() and OLD_PACKAGE.is_file() and
            not OLD_PACKAGE.is_symlink() and BACKUP.is_dir() and not BACKUP.is_symlink(),
            "rollback paths missing or symlinked")
    saved_manifest = BACKUP / "debug.json.before"
    saved_old_apk = BACKUP / OLD_APK_NAME
    saved_new_manifest = BACKUP / "debug.json.91015"
    saved_receipt = BACKUP / "receipt.json"
    for path in (saved_manifest, saved_old_apk, saved_new_manifest, saved_receipt):
        require(path.is_file() and not path.is_symlink(), "rollback archive file missing or symlinked: " + path.name)
    old_raw = saved_manifest.read_bytes()
    old_size = verify_old(old_raw, saved_old_apk)
    require(OLD_PACKAGE.stat().st_size == old_size and file_sha(OLD_PACKAGE) == OLD_APK_SHA,
            "live 91014 APK differs from preserved rollback APK")
    receipt = parse(saved_receipt.read_bytes())
    current = MANIFEST.read_bytes()
    saved_new = saved_new_manifest.read_bytes()
    expected_receipt_fields = {"status", "channel", "host", "manifestUrl", "publishedAt", "versionCode",
                               "versionName", "manifestSha256", "apkSha256", "apkBytes", "signingIdentity",
                               "baselineManifestSha256", "baselineApkSha256", "backup", "backendChanged",
                               "backendRestarted", "rollbackDataPolicy", "officialManifestValidation",
                               "httpsReadback"}
    require(set(receipt) == expected_receipt_fields and receipt.get("status") == "DEPLOYED_HTTPS_VERIFIED" and
            receipt.get("channel") == "debug" and receipt.get("host") == HOST and
            receipt.get("manifestUrl") == MANIFEST_URL and receipt.get("versionCode") == 91015 and
            receipt.get("versionName") == "0.9.15-debug.15" and receipt.get("publishedAt") == parse(saved_new).get("publishedAt") and
            receipt.get("manifestSha256") == digest(saved_new) and receipt.get("apkSha256") == NEW_APK_SHA and
            receipt.get("apkBytes") == NEW_APK_SIZE and receipt.get("signingIdentity") == SIGNER and
            receipt.get("baselineManifestSha256") == OLD_MANIFEST_SHA and
            receipt.get("baselineApkSha256") == OLD_APK_SHA and receipt.get("backup") == str(BACKUP) and
            receipt.get("backendChanged") is False and receipt.get("backendRestarted") is False and
            receipt.get("rollbackDataPolicy") == "KEEP_LIVE_DATA" and
            receipt.get("officialManifestValidation") == {
                "validatorSha256": "03f57404eaab5d01f14315780a66b58921ac6464a46a1189ad98e7da977ce1b0",
                "installedVersionCode": 91014} and type(receipt.get("httpsReadback")) is dict and
            receipt["httpsReadback"].get("manifestSha256") == digest(saved_new) and
            receipt["httpsReadback"].get("apkSha256") == NEW_APK_SHA and
            receipt["httpsReadback"].get("apkBytes") == NEW_APK_SIZE and current == saved_new,
            "live manifest does not exactly match verified 91015 archive")
    verify_current_91015(current)
    pre_rollback_https = verify_https(current, NEW_APK_SHA, NEW_APK_SIZE, 91015,
                                      "0.9.15-debug.15", NEW_PACKAGE_URL)
    require(not (BACKUP / "rollback-receipt.json").exists(), "rollback receipt already exists")
    require(MANIFEST.read_bytes() == saved_new and
            PACKAGE.is_file() and not PACKAGE.is_symlink() and
            PACKAGE.stat().st_size == NEW_APK_SIZE and file_sha(PACKAGE) == NEW_APK_SHA,
            "live 91015 manifest or APK changed during rollback preflight")
    mode = MANIFEST.stat().st_mode & 0o777
    atomic_write(MANIFEST, old_raw, mode)
    post_rollback_https = verify_https(old_raw, OLD_APK_SHA, old_size, 91014,
                                       "0.9.14-debug.14", OLD_PACKAGE_URL)
    result = {"status": "ROLLED_BACK_91014_HTTPS_VERIFIED", "channel": "debug",
              "host": HOST, "rolledBackAt": datetime.now(timezone.utc).replace(microsecond=0)
                  .isoformat().replace("+00:00", "Z"),
              "manifestSha256": OLD_MANIFEST_SHA, "apkSha256": OLD_APK_SHA,
              "retained91015ApkSha256": NEW_APK_SHA, "backendChanged": False,
              "backendRestarted": False, "rollbackDataPolicy": "KEEP_LIVE_DATA",
              "preRollbackHttps": pre_rollback_https, "postRollbackHttps": post_rollback_https}
    path = BACKUP / "rollback-receipt.json"
    encoded = (json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode("utf-8")
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "wb") as stream:
        stream.write(encoded)
        stream.flush()
        os.fsync(stream.fileno())
    fsync_dir(BACKUP)
    print(json.dumps(result, ensure_ascii=False, sort_keys=True), flush=True)


if __name__ == "__main__":
    try:
        with release_lock():
            rollback()
    except Exception as error:
        print("FAIL " + (str(error) or type(error).__name__), flush=True)
        raise SystemExit(1)
