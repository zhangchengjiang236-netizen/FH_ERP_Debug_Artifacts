#!/usr/bin/env python3
"""Deploy only the authorized Android Debug 91016 manifest and APK."""
from __future__ import annotations

import fcntl
import stat
from contextlib import contextmanager
import hashlib
import json
import os
import re
import signal
import socket
import subprocess
import sys
import tempfile
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

HOST = "iZ2vc2shy5e95mfqeid9khZ"
ROOT = Path("/var/www/erp-uat-updates")
MANIFEST = ROOT / "android/debug.json"
APK_NAME = "feihong-erp-0.9.16-debug.16.apk"
OLD_APK_NAME = "feihong-erp-0.9.15-debug.15.apk"
PACKAGE = ROOT / "debug-packages" / APK_NAME
OLD_PACKAGE = ROOT / "debug-packages" / OLD_APK_NAME
BACKUP = ROOT / "archive/DEBUG-91016-20261007"
MANIFEST_URL = "https://api-test.scxmj.cn/mobile-updates/android/debug.json"
PACKAGE_URL = "https://api-test.scxmj.cn/mobile-updates/debug-packages/" + APK_NAME
OLD_PACKAGE_URL = "https://api-test.scxmj.cn/mobile-updates/debug-packages/" + OLD_APK_NAME
ORIGIN = "https://appassets.androidplatform.net"
SIGNER = "sha256:a182e8f2b6b60e71acf6e29184558fd3b210b5c8748a8beeb75de0bace3355a4"
OLD_MANIFEST_SHA = "4991be26eb37900433d32a653f8829738c4c419bf1e297149bbcc1728a565bac"
OLD_APK_SHA = "049a46f1425531a77c93c610f242b6a2783edc02b34423e9f6a1bfac3ad8dc24"
NEW_APK_SHA = "989fb9a830f46af6f57ff0300fa0fccd2fc52cc0243fba8c68df402335e6463f"
NEW_APK_SIZE = 1042507
DRAFT_MANIFEST_SHA = "ce02a542fe01bf95cbddee78686db24edf74b6ae11bbe120e9ee2044cc93d6b1"
VALIDATOR_NAME = "validate_update_manifest.py"
VALIDATOR_SHA = "03f57404eaab5d01f14315780a66b58921ac6464a46a1189ad98e7da977ce1b0"


@contextmanager
def release_lock():
    require(socket.gethostname() == HOST and os.geteuid() == 0, "wrong host or execution user")
    require(ROOT.is_dir() and not ROOT.is_symlink(), "root missing or symlinked")
    lockpath = ROOT / ".android-debug-release.lock"
    fd = os.open(lockpath, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
    try:
        st = os.fstat(fd)
        require(stat.S_ISREG(st.st_mode) and st.st_nlink == 1 and st.st_uid == 0,
                "release lock identity mismatch")
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        yield
    finally:
        os.close(fd)
    # Keep lock inode; deleting it would let different processes lock different inodes.


class TerminationRequested(Exception):
    pass


def request_termination(signum, frame) -> None:
    raise TerminationRequested("SIGTERM")


def digest(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def sha256(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def parse_manifest(raw: bytes) -> dict:
    def unique_pairs(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "duplicate manifest field")
            result[key] = value
        return result
    value = json.loads(raw.decode("utf-8"), object_pairs_hook=unique_pairs)
    require(type(value) is dict, "manifest must be a JSON object")
    return value


def fsync_dir(directory: Path) -> None:
    fd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def stage_bytes(target: Path, raw: bytes, mode: int) -> Path:
    fd, name = tempfile.mkstemp(prefix="." + target.name + ".", suffix=".tmp", dir=target.parent)
    staged = Path(name)
    try:
        with os.fdopen(fd, "wb") as stream:
            os.fchmod(stream.fileno(), mode)
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        require(staged.read_bytes() == raw, "staged bytes mismatch")
        return staged
    except BaseException:
        staged.unlink(missing_ok=True)
        raise


def stage_copy(source: Path, target: Path, expected_sha: str, size: int) -> Path:
    fd, name = tempfile.mkstemp(prefix="." + target.name + ".", suffix=".tmp", dir=target.parent)
    staged = Path(name)
    try:
        with os.fdopen(fd, "wb") as outgoing, source.open("rb") as incoming:
            os.fchmod(outgoing.fileno(), 0o644)
            for block in iter(lambda: incoming.read(1024 * 1024), b""):
                outgoing.write(block)
            outgoing.flush()
            os.fsync(outgoing.fileno())
        require(staged.stat().st_size == size and sha256(staged) == expected_sha,
                "staged APK size/SHA mismatch")
        return staged
    except BaseException:
        staged.unlink(missing_ok=True)
        raise


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def fetch_https(url: str, expected_size: int) -> tuple[bytes, dict[str, str]]:
    request = urllib.request.Request(url, headers={"Origin": ORIGIN, "Cache-Control": "no-cache"})
    opener = urllib.request.build_opener(NoRedirect())
    with opener.open(request, timeout=30) as response:
        require(response.status == 200 and response.geturl() == url, "HTTPS status/redirect mismatch")
        require(response.headers.get_all("Access-Control-Allow-Origin") == [ORIGIN],
                "HTTPS exact CORS mismatch")
        require("Origin" in response.headers.get("Vary", ""), "HTTPS Vary mismatch")
        raw = response.read(expected_size + 1)
        require(len(raw) == expected_size, "HTTPS byte count mismatch")
        headers = {key.lower(): value for key, value in response.headers.items()}
        return raw, headers


def verify_old_manifest(raw: bytes, old_apk: Path) -> int:
    require(digest(raw) == OLD_MANIFEST_SHA, "live 91015 manifest SHA mismatch")
    data = parse_manifest(raw)
    size = old_apk.stat().st_size
    require(sha256(old_apk) == OLD_APK_SHA, "live 91015 APK SHA mismatch")
    require(type(data.get("versionCode")) is int and data["versionCode"] == 91015 and
            data.get("versionName") == "0.9.15-debug.15" and data.get("channel") == "debug" and
            data.get("downloadUrl") == OLD_PACKAGE_URL and data.get("fileSize") == size and
            data.get("sha256") == OLD_APK_SHA and data.get("signingIdentity") == SIGNER,
            "live 91015 manifest identity/URL/hash mismatch")
    return size


def prepare_candidate(base: Path) -> tuple[dict, Path]:
    raw = (base / "manifest.json").read_bytes()
    require(digest(raw) == DRAFT_MANIFEST_SHA, "91016 draft manifest SHA mismatch")
    data = parse_manifest(raw)
    require(type(data.get("versionCode")) is int and data["versionCode"] == 91016 and
            data.get("versionName") == "0.9.16-debug.16" and data.get("channel") == "debug" and
            data.get("minimumVersion") == "90901" and data.get("mandatory") is False and
            data.get("downloadUrl") == PACKAGE_URL and data.get("signingIdentity") == SIGNER and
            data.get("fileSize") == NEW_APK_SIZE and data.get("sha256") == NEW_APK_SHA and
            data.get("platform") == "android" and data.get("schemaVersion") == 1,
            "91016 candidate manifest fields mismatch")
    require(set(data) == {"channel", "downloadUrl", "fileSize", "mandatory", "minimumVersion",
                          "platform", "publishedAt", "releaseNotes", "schemaVersion", "sha256",
                          "signingIdentity", "versionCode", "versionName"},
            "91016 candidate manifest field set mismatch")
    apk = base / APK_NAME
    require(apk.is_file() and apk.stat().st_size == NEW_APK_SIZE and sha256(apk) == NEW_APK_SHA,
            "91016 APK size/SHA mismatch")
    return data, apk


def make_published_manifest(data: dict, published_at: str) -> bytes:
    final = dict(data)
    final["publishedAt"] = published_at
    return (json.dumps(final, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def verify_https_manifest(expected: bytes, expected_apk_sha: str, expected_apk_size: int,
                          version_code: int, version_name: str, package_url: str) -> dict:
    returned, manifest_headers = fetch_https(MANIFEST_URL, len(expected))
    require(digest(returned) == digest(expected), "HTTPS manifest SHA mismatch")
    require("no-store" in manifest_headers.get("cache-control", "").lower(),
            "HTTPS manifest cache-control must include no-store")
    data = parse_manifest(returned)
    require(type(data.get("versionCode")) is int and data["versionCode"] == version_code and
            data.get("versionName") == version_name and data.get("channel") == "debug" and
            data.get("downloadUrl") == package_url and data.get("fileSize") == expected_apk_size and
            data.get("sha256") == expected_apk_sha and data.get("signingIdentity") == SIGNER,
            "HTTPS manifest values mismatch")
    package, package_headers = fetch_https(package_url, expected_apk_size)
    require(digest(package) == expected_apk_sha, "HTTPS APK SHA mismatch")
    return {"manifestBytes": len(returned), "manifestSha256": digest(returned),
            "manifestCacheControl": manifest_headers.get("cache-control", ""),
            "apkBytes": len(package), "apkSha256": digest(package),
            "apkCacheControl": package_headers.get("cache-control", "")}


def create_backup() -> tuple[bytes, int, int]:
    require(not BACKUP.exists() and not BACKUP.is_symlink(), "91016 backup path already exists")
    raw = MANIFEST.read_bytes()
    size = verify_old_manifest(raw, OLD_PACKAGE)
    verify_https_manifest(raw, OLD_APK_SHA, size, 91015, "0.9.15-debug.15", OLD_PACKAGE_URL)
    mode = MANIFEST.stat().st_mode & 0o777
    BACKUP.parent.mkdir(exist_ok=True)
    BACKUP.mkdir()
    fsync_dir(BACKUP.parent)
    saved_manifest = BACKUP / "debug.json.before"
    staged = stage_bytes(saved_manifest, raw, mode)
    try:
        os.link(staged, saved_manifest)
    finally:
        staged.unlink(missing_ok=True)
    saved_apk = BACKUP / OLD_APK_NAME
    staged = stage_copy(OLD_PACKAGE, saved_apk, OLD_APK_SHA, size)
    try:
        os.link(staged, saved_apk)
    finally:
        staged.unlink(missing_ok=True)
    fsync_dir(BACKUP)
    require(saved_manifest.read_bytes() == raw and sha256(saved_apk) == OLD_APK_SHA,
            "91016 remote rollback copy mismatch")
    return raw, size, mode


def restore_backup() -> dict:
    old_raw = (BACKUP / "debug.json.before").read_bytes()
    old_size = verify_old_manifest(old_raw, BACKUP / OLD_APK_NAME)
    require(OLD_PACKAGE.stat().st_size == old_size and sha256(OLD_PACKAGE) == OLD_APK_SHA,
            "preserved 91015 APK mismatch")
    mode = (BACKUP / "debug.json.before").stat().st_mode & 0o777
    staged = stage_bytes(MANIFEST, old_raw, mode)
    try:
        os.replace(staged, MANIFEST)
        staged = None
        fsync_dir(MANIFEST.parent)
    finally:
        if staged is not None:
            staged.unlink(missing_ok=True)
    return verify_https_manifest(old_raw, OLD_APK_SHA, old_size, 91015,
                                 "0.9.15-debug.15", OLD_PACKAGE_URL)


def write_receipt(receipt: dict) -> None:
    path = BACKUP / "receipt.json"
    raw = (json.dumps(receipt, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode("utf-8")
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "wb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    fsync_dir(BACKUP)


def deploy(base: Path) -> None:
    require(socket.gethostname() == HOST, "must run on authorized 91016 server")
    require(ROOT.is_dir() and not ROOT.is_symlink() and MANIFEST.is_file() and
            not MANIFEST.is_symlink() and OLD_PACKAGE.is_file() and not OLD_PACKAGE.is_symlink(),
            "server paths missing or symlinked")
    root_real = ROOT.resolve(strict=True)
    for child in ("android", "debug-packages", "archive"):
        directory = ROOT / child
        require(directory.is_dir() and not directory.is_symlink() and
                directory.resolve(strict=True) == root_real / child,
                "server directory missing, symlinked, or escaped root: " + child)
    require(not PACKAGE.exists() and not PACKAGE.is_symlink(), "91016 package path already exists")
    candidate, apk = prepare_candidate(base)
    validator = base / VALIDATOR_NAME
    require(validator.is_file() and not validator.is_symlink() and sha256(validator) == VALIDATOR_SHA,
            "official manifest validator is missing, symlinked, or changed")
    old_raw, old_size, manifest_mode = create_backup()
    staged_package = staged_manifest = None
    switch_started = False
    final_manifest = None
    previous_term = signal.signal(signal.SIGTERM, request_termination)
    try:
        staged_package = stage_copy(apk, PACKAGE, NEW_APK_SHA, NEW_APK_SIZE)
        os.link(staged_package, PACKAGE)
        staged_package.unlink()
        staged_package = None
        fsync_dir(PACKAGE.parent)
        require(PACKAGE.stat().st_size == NEW_APK_SIZE and sha256(PACKAGE) == NEW_APK_SHA,
                "new server APK mismatch before switch")
        downloaded, headers = fetch_https(PACKAGE_URL, NEW_APK_SIZE)
        require(digest(downloaded) == NEW_APK_SHA and "Origin" in headers.get("vary", "") and
                "immutable" in headers.get("cache-control", "").lower(),
                "new HTTPS APK mismatch before switch")
        require(MANIFEST.read_bytes() == old_raw, "live manifest changed before switch")
        require(OLD_PACKAGE.stat().st_size == old_size and sha256(OLD_PACKAGE) == OLD_APK_SHA,
                "live 91015 APK changed before switch")
        switch_utc = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
        final_manifest = make_published_manifest(candidate, switch_utc)
        published = parse_manifest(final_manifest)
        require(type(published.get("versionCode")) is int and published["versionCode"] == 91016 and
                published["versionName"] == "0.9.16-debug.16" and published["publishedAt"] == switch_utc,
                "final 91016 manifest validation failed")
        saved_candidate = BACKUP / "debug.json.91016"
        fd = os.open(saved_candidate, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "wb") as stream:
            stream.write(final_manifest)
            stream.flush()
            os.fsync(stream.fileno())
        fsync_dir(BACKUP)
        subprocess.run([sys.executable, "-I", "-B", str(validator), str(saved_candidate),
                        "--package", str(apk), "--installed-version-code", "91015"],
                       check=True, timeout=60)
        require(MANIFEST.read_bytes() == old_raw,
                "live manifest changed during official final manifest validation")
        staged_manifest = stage_bytes(MANIFEST, final_manifest, manifest_mode)
        require(MANIFEST.read_bytes() == old_raw, "live manifest changed at atomic switch boundary")
        verify_https_manifest(old_raw, OLD_APK_SHA, old_size, 91015,
                             "0.9.15-debug.15", OLD_PACKAGE_URL)
        switch_started = True
        os.replace(staged_manifest, MANIFEST)
        staged_manifest = None
        fsync_dir(MANIFEST.parent)
        require(MANIFEST.read_bytes() == final_manifest, "local 91016 manifest switch mismatch")
        https = verify_https_manifest(final_manifest, NEW_APK_SHA, NEW_APK_SIZE, 91016,
                                      "0.9.16-debug.16", PACKAGE_URL)
        receipt = {"status": "DEPLOYED_HTTPS_VERIFIED", "channel": "debug",
                   "host": HOST, "manifestUrl": MANIFEST_URL,
                   "publishedAt": switch_utc, "versionCode": 91016,
                   "versionName": "0.9.16-debug.16", "manifestSha256": digest(final_manifest),
                   "apkSha256": NEW_APK_SHA, "apkBytes": NEW_APK_SIZE,
                   "signingIdentity": SIGNER, "baselineManifestSha256": OLD_MANIFEST_SHA,
                   "baselineApkSha256": OLD_APK_SHA, "backup": str(BACKUP),
                   "backendChanged": False, "backendRestarted": False,
                   "rollbackDataPolicy": "KEEP_LIVE_DATA", "officialManifestValidation": {
                       "validatorSha256": VALIDATOR_SHA, "installedVersionCode": 91015},
                   "httpsReadback": https}
        write_receipt(receipt)
        print(json.dumps(receipt, ensure_ascii=False, sort_keys=True), flush=True)
    except BaseException as original:
        if switch_started:
            try:
                require(final_manifest is not None and MANIFEST.read_bytes() == final_manifest,
                        "refuse automatic rollback: live manifest changed by another publisher")
                rollback_https = restore_backup()
                print(json.dumps({"status": "ROLLED_BACK_91015", "baselineManifestSha256": OLD_MANIFEST_SHA,
                                  "baselineApkSha256": OLD_APK_SHA, "httpsReadback": rollback_https},
                                 sort_keys=True), file=sys.stderr, flush=True)
            except BaseException as recovery:
                raise RuntimeError("deployment failed and rollback verification failed: " + str(recovery)) from original
        raise
    finally:
        for staged in (staged_package, staged_manifest):
            if staged is not None:
                staged.unlink(missing_ok=True)
        signal.signal(signal.SIGTERM, previous_term)


def main() -> int:
    require(len(sys.argv) == 1, "usage: python3 deploy_debug_91016.py")
    with release_lock():
        deploy(Path(__file__).resolve().parent)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (Exception, KeyboardInterrupt) as error:
        print("FAIL " + (str(error) or type(error).__name__), file=sys.stderr, flush=True)
        raise SystemExit(1)
