#!/usr/bin/env python3
"""Server-local atomic restore of DEBUG-91002-20260922; old APK stays intact."""
import sys
import deploy_debug_91002 as publication


def main() -> int:
    publication.require(len(sys.argv) == 1, "usage: python3 rollback_debug_91002.py")
    publication.require_host()
    publication.restore_backup()
    print("ROLLBACK PASS manifestSHA=" + publication.OLD_MANIFEST_SHA + " versionCode=91001 apkSHA=" +
          publication.OLD_APK_SHA + " HTTPS=200,CORS-exact,hash-size-verified", flush=True)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (Exception, KeyboardInterrupt) as error:
        print("FAIL " + (str(error) or type(error).__name__), file=sys.stderr)
        raise SystemExit(1)
