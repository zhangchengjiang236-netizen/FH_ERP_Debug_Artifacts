#!/usr/bin/env python3
"""Server-local publication of the authorized Android Debug 91001 candidate."""
from __future__ import annotations
import hashlib
import json
import os
import re
import signal
import socket
import sys
import tempfile
import urllib.request
from pathlib import Path

HOST = "iZ2vc2shy5e95mfqeid9khZ"
ROOT = Path("/var/www/erp-uat-updates")
MANIFEST = ROOT / "android/debug.json"
APK_NAME = "feihong-erp-0.9.10-debug.1.apk"
OLD_APK_NAME = "feihong-erp-0.9.9-debug.1.apk"
PACKAGE = ROOT / "debug-packages" / APK_NAME
OLD_PACKAGE = ROOT / "debug-packages" / OLD_APK_NAME
BACKUP = ROOT / "archive/DEBUG-91001-20260914"
MANIFEST_URL = "https://api-test.scxmj.cn/mobile-updates/android/debug.json"
PACKAGE_URL = "https://api-test.scxmj.cn/mobile-updates/debug-packages/" + APK_NAME
OLD_PACKAGE_URL = "https://api-test.scxmj.cn/mobile-updates/debug-packages/" + OLD_APK_NAME
ORIGIN = "https://appassets.androidplatform.net"
SIGNER = "sha256:a182e8f2b6b60e71acf6e29184558fd3b210b5c8748a8beeb75de0bace3355a4"
OLD_MANIFEST_SHA = "07aa004ac0912ab59359b4cf98f096a3a2af631c089fca1c6c1d7f23a54fea5d"
OLD_APK_SHA = "80dffe3f872e81d4fd587634fb83d466c7b2f7c76032ecf14c88a9753344a732"


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def require_host() -> None:
    require(socket.gethostname() == HOST, "must run locally on the authorized server")


def parse_manifest(raw: bytes) -> dict:
    def unique_pairs(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "duplicate manifest field")
            result[key] = value
        return result
    result = json.loads(raw.decode("utf-8"), object_pairs_hook=unique_pairs)
    require(type(result) is dict, "manifest must be a JSON object")
    return result


def local_inputs(base: Path, expected_manifest_sha: str):
    require(re.fullmatch(r"[0-9a-fA-F]{64}", expected_manifest_sha) is not None,
            "expected manifest SHA must be exactly 64 hex characters")
    raw = (base / "debug.json").read_bytes()
    # Pin approved bytes before parsing self-described fields.
    require(digest(raw) == expected_manifest_sha.lower(), "input manifest SHA mismatch")
    data = parse_manifest(raw)
    required = {"versionCode", "versionName", "channel", "minimumVersion", "mandatory",
                "downloadUrl", "signingIdentity", "fileSize", "sha256"}
    require(required <= data.keys(), "required manifest field missing")
    require(data.keys() <= required | {"publishedAt", "releaseNotes", "platform"},
            "unsupported manifest field")
    require(type(data["versionCode"]) is int and data["versionCode"] == 91001,
            "versionCode must be integer 91001")
    require(data["versionName"] == "0.9.10-debug.1" and data["channel"] == "debug",
            "versionName/channel mismatch")
    require(type(data["minimumVersion"]) is str and data["minimumVersion"] == "90901",
            "minimumVersion must be string 90901")
    require(data["mandatory"] is False, "mandatory must be false")
    require(data["downloadUrl"] == PACKAGE_URL, "downloadUrl mismatch")
    require(data["signingIdentity"] == SIGNER, "signingIdentity mismatch")
    for key in ("publishedAt", "releaseNotes"):
        if key in data:
            require(type(data[key]) is str, key + " must be a string")
    if "platform" in data:
        require(data["platform"] == "android", "platform must be android")
    require(type(data["fileSize"]) is int and data["fileSize"] > 0, "invalid fileSize")
    require(type(data["sha256"]) is str and
            re.fullmatch(r"[0-9a-f]{64}", data["sha256"]) is not None, "invalid APK SHA")
    apk = base / APK_NAME
    size, apk_sha = apk.stat().st_size, sha256(apk)
    require(size == data["fileSize"] and apk_sha == data["sha256"], "input APK size/SHA mismatch")
    return raw, apk, size, apk_sha


def fsync_dir(directory: Path) -> None:
    descriptor = os.open(directory, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def stage_bytes(target: Path, raw: bytes, mode: int) -> Path:
    descriptor, name = tempfile.mkstemp(prefix="." + target.name + ".", suffix=".tmp", dir=target.parent)
    staged = Path(name)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            os.fchmod(stream.fileno(), mode)
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        require(staged.read_bytes() == raw, "staged bytes mismatch")
        return staged
    except BaseException:
        staged.unlink(missing_ok=True)
        raise


def stage_copy(source: Path, target: Path, expected_sha: str, size: int) -> Path:
    descriptor, name = tempfile.mkstemp(prefix="." + target.name + ".", suffix=".tmp", dir=target.parent)
    staged = Path(name)
    try:
        with os.fdopen(descriptor, "wb") as outgoing, source.open("rb") as incoming:
            os.fchmod(outgoing.fileno(), 0o644)
            for block in iter(lambda: incoming.read(1024 * 1024), b""):
                outgoing.write(block)
            outgoing.flush()
            os.fsync(outgoing.fileno())
        require(staged.stat().st_size == size and sha256(staged) == expected_sha,
                "staged APK size/SHA mismatch")
        return staged
    except BaseException:
        staged.unlink(missing_ok=True)
        raise


def publish_no_overwrite(staged: Path, target: Path, expected_sha: str, size: int) -> None:
    try:
        os.link(staged, target)
    except FileExistsError:
        require(target.is_file() and target.stat().st_size == size and sha256(target) == expected_sha,
                "existing package differs; refused overwrite")
    fsync_dir(target.parent)


def check_old(raw: bytes, apk: Path):
    require(digest(raw) == OLD_MANIFEST_SHA, "old manifest SHA mismatch")
    require(sha256(apk) == OLD_APK_SHA, "old APK SHA mismatch")
    data = parse_manifest(raw)
    require(type(data.get("versionCode")) is int and data["versionCode"] == 90901 and
            data.get("versionName") == "0.9.9-debug.1" and data.get("channel") == "debug" and
            data.get("downloadUrl") == OLD_PACKAGE_URL, "old manifest version/URL mismatch")
    size = apk.stat().st_size
    require(type(data.get("fileSize")) is int and data["fileSize"] == size and
            data.get("sha256") == OLD_APK_SHA, "old manifest APK size/SHA mismatch")
    return size


def create_backup():
    raw = MANIFEST.read_bytes()
    size = check_old(raw, OLD_PACKAGE)
    mode = MANIFEST.stat().st_mode & 0o777
    BACKUP.parent.mkdir(exist_ok=True)
    BACKUP.mkdir()  # Exclusive: existing backup is never reused or overwritten.
    fsync_dir(BACKUP.parent)
    saved_manifest = BACKUP / "debug.json.before"
    staged = stage_bytes(saved_manifest, raw, mode)
    try:
        os.link(staged, saved_manifest)
    finally:
        staged.unlink(missing_ok=True)
    saved_apk = BACKUP / OLD_APK_NAME
    staged = stage_copy(OLD_PACKAGE, saved_apk, OLD_APK_SHA, size)
    try:
        os.link(staged, saved_apk)
    finally:
        staged.unlink(missing_ok=True)
    fsync_dir(BACKUP)
    check_old(saved_manifest.read_bytes(), saved_apk)
    return raw, size, mode


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def fetch_https(url: str, expected_size: int) -> bytes:
    request = urllib.request.Request(url, headers={"Origin": ORIGIN, "Cache-Control": "no-cache"})
    # Default HTTPSHandler retains system CA trust and TLS hostname validation.
    opener = urllib.request.build_opener(NoRedirect())
    with opener.open(request, timeout=30) as response:
        require(response.status == 200 and response.geturl() == url, "HTTPS status/redirect mismatch")
        require(response.headers.get_all("Access-Control-Allow-Origin") == [ORIGIN],
                "HTTPS exact CORS mismatch")
        raw = response.read(expected_size + 1)
        require(len(raw) == expected_size, "HTTPS byte count mismatch")
        return raw


def verify_https(raw: bytes, apk_sha: str, apk_size: int, old: bool = False) -> None:
    returned = fetch_https(MANIFEST_URL, len(raw))
    require(digest(returned) == digest(raw), "HTTPS manifest SHA mismatch")
    data = parse_manifest(returned)
    code, name, url = ((90901, "0.9.9-debug.1", OLD_PACKAGE_URL) if old else
                       (91001, "0.9.10-debug.1", PACKAGE_URL))
    require(type(data.get("versionCode")) is int and data["versionCode"] == code and
            data.get("versionName") == name and data.get("channel") == "debug" and
            data.get("downloadUrl") == url, "HTTPS manifest version/URL mismatch")
    package = fetch_https(url, apk_size)
    # Independent preflight values, never returned JSON alone.
    require(digest(package) == apk_sha, "HTTPS APK SHA mismatch")


def restore_backup() -> None:
    # Finish recovery if the original failure was Ctrl-C or another Ctrl-C arrives.
    previous = signal.signal(signal.SIGINT, signal.SIG_IGN)
    staged = None
    try:
        raw = (BACKUP / "debug.json.before").read_bytes()
        size = check_old(raw, BACKUP / OLD_APK_NAME)
        require(OLD_PACKAGE.stat().st_size == size and sha256(OLD_PACKAGE) == OLD_APK_SHA,
                "preserved old APK size/SHA mismatch")
        mode = (BACKUP / "debug.json.before").stat().st_mode & 0o777
        staged = stage_bytes(MANIFEST, raw, mode)
        os.replace(staged, MANIFEST)
        fsync_dir(MANIFEST.parent)
        require(digest(MANIFEST.read_bytes()) == OLD_MANIFEST_SHA, "restored local SHA mismatch")
        verify_https(raw, OLD_APK_SHA, size, old=True)
    finally:
        if staged is not None:
            staged.unlink(missing_ok=True)
        signal.signal(signal.SIGINT, previous)


def deploy(expected_manifest_sha: str, base: Path | None = None) -> int:
    require_host()
    raw, apk, apk_size, apk_sha = local_inputs(base or Path(__file__).resolve().parent, expected_manifest_sha)
    old_raw, old_size, manifest_mode = create_backup()
    staged_package = staged_manifest = None
    switch_started = False
    try:
        staged_package = stage_copy(apk, PACKAGE, apk_sha, apk_size)
        publish_no_overwrite(staged_package, PACKAGE, apk_sha, apk_size)
        staged_package.unlink()
        staged_package = None
        staged_manifest = stage_bytes(MANIFEST, raw, manifest_mode)
        require(MANIFEST.read_bytes() == old_raw, "current manifest changed before switch")
        require(OLD_PACKAGE.stat().st_size == old_size and sha256(OLD_PACKAGE) == OLD_APK_SHA,
                "old APK changed before switch")
        # Set before replace: interruption immediately after replacement also restores.
        switch_started = True
        os.replace(staged_manifest, MANIFEST)
        staged_manifest = None
        fsync_dir(MANIFEST.parent)
        require(MANIFEST.read_bytes() == raw, "local manifest switch mismatch")
        verify_https(raw, apk_sha, apk_size)
        print("PASS rollbackid=DEBUG-91001-20260914 manifestSHA=" + digest(raw) +
              " apkSHA=" + apk_sha + " HTTPS=200,CORS-exact,hash-size-verified", flush=True)
        return 0
    except BaseException as original:
        if switch_started:
            try:
                restore_backup()
            except BaseException as recovery:
                raise RuntimeError("deployment failed; rollback verification also failed: " + str(recovery)) from original
            print("ROLLBACK PASS manifestSHA=" + OLD_MANIFEST_SHA + " versionCode=90901 apkSHA=" +
                  OLD_APK_SHA, file=sys.stderr, flush=True)
        raise
    finally:
        for staged in (staged_package, staged_manifest):
            if staged is not None:
                staged.unlink(missing_ok=True)


def main() -> int:
    require(len(sys.argv) == 2, "usage: python3 deploy_debug_91001.py EXPECTED_MANIFEST_SHA")
    return deploy(sys.argv[1])


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (Exception, KeyboardInterrupt) as error:
        print("FAIL " + (str(error) or type(error).__name__), file=sys.stderr)
        raise SystemExit(1)
